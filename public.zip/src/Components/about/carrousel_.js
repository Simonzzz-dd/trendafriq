import { Carousel } from "react-bootstrap";
import { useState } from "react";

const Carrousel_ab = () => {


  return (
        <div className="aboutImage">
            <img src="https://images.unsplash.com/photo-1552879890-3a06dd3a06c2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=954&q=80" alt="" />
        </div>
  );

}
 
export default Carrousel_ab;