import {  Container } from 'react-bootstrap';
import "../../styles/SectionThree.scss"



const Section3 = () => {
    return ( 
        <>

            <div className="section-3">
                <h1 >
                    PROBABLY MIGHT HAVE SOME DOUBTS OF HOW WE PERFORM,
                    DOWN BELLOW, THERE IS A SHOWCASE OF SOME OF OUR PROGECTS
                </h1>
            </div>

        </>
     );
}
 
export default Section3 ;